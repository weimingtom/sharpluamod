See my blog : http://blog.codingnow.com/2017/01/unity3d_sharplua.html

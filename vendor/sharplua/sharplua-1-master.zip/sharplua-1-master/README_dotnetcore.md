* https://docs.microsoft.com/en-us/dotnet/core/api/index  
* https://dotnet.github.io  
* https://www.microsoft.com/net/core  
* https://msdn.microsoft.com/zh-cn/library/system.type.aspx  
* http://stackoverflow.com/questions/21499327/is-there-any-equivalent-of-type-isinterface-or-isclass-in-windows-store-net  
